# RabInfoCellUserInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ecgi** | [**Ecgi**](Ecgi.md) |  | [optional] 
**ue_info** | [**list[RabInfoUeInfo]**](RabInfoUeInfo.md) | Information on UEs in the specific cell as defined below. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

