# NrMeasRepUeNotificationNCell

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meas_quantity_results_csi_rs_cell** | [**MeasQuantityResultsNr**](MeasQuantityResultsNr.md) |  | [optional] 
**meas_quantity_results_ssb_cell** | [**MeasQuantityResultsNr**](MeasQuantityResultsNr.md) |  | [optional] 
**rs_index_results** | [**RsIndexResults**](RsIndexResults.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

