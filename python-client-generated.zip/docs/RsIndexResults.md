# RsIndexResults

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results_csi_rs_indexes** | [**ResultsPerCsiRsIndexList**](ResultsPerCsiRsIndexList.md) |  | 
**results_ssb_indexes** | [**ResultsPerSsbIndexList**](ResultsPerSsbIndexList.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

