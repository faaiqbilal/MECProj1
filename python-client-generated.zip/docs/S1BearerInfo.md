# S1BearerInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**s1_ue_info** | [**list[S1BearerInfoS1UeInfo]**](S1BearerInfoS1UeInfo.md) | Information on a specific UE as defined below. | 
**time_stamp** | [**TimeStamp**](TimeStamp.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

