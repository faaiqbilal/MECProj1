# RabEstNotificationTempUeId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mmec** | **str** | MMEC as defined in ETSI TS 136 413 [i.3]. | 
**mtmsi** | **str** | M-TMSI as defined in ETSI TS 136 413 [i.3]. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

