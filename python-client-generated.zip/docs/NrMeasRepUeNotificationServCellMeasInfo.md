# NrMeasRepUeNotificationServCellMeasInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**n_cell** | [**NrMeasRepUeNotificationNCell**](NrMeasRepUeNotificationNCell.md) |  | [optional] 
**nrcgi** | [**NRcgi**](NRcgi.md) |  | [optional] 
**s_cell** | [**NrMeasRepUeNotificationSCell**](NrMeasRepUeNotificationSCell.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

