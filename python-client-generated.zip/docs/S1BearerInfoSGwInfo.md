# S1BearerInfoSGwInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip_address** | **str** | SGW transport layer address of this S1 bearer. | 
**tunnel_id** | **str** | SGW GTP-U TEID of this S1 bearer. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

