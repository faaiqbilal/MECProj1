# SubscriptionLinkListLinksSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **str** | The URI referring to the subscription. | [optional] 
**subscription_type** | **str** | Type of the subscription. The string shall be set according to the \&quot;subscriptionType\&quot; attribute of the associated subscription data type event defined in clause 6.3. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

