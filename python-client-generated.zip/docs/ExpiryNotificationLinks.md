# ExpiryNotificationLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_self** | **str** | Self referring URI. This shall be included in the response from the RNIS. The URI shall be unique within the RNI API as it acts as an ID for the subscription. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

