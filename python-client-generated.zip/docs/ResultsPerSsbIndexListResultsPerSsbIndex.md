# ResultsPerSsbIndexListResultsPerSsbIndex

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ssb_index** | **int** |  | [optional] 
**ssb_results** | [**MeasQuantityResultsNr**](MeasQuantityResultsNr.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

