# MeasRepUeNotificationNrSCsNrSCellInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nr_s_cell_g_id** | [**NrCellId**](NrCellId.md) |  | [optional] 
**nr_s_cell_plmn** | [**list[Plmn]**](Plmn.md) | Public land mobile network identities. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

