# RabInfoUeInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**associate_id** | [**list[AssociateId]**](AssociateId.md) | 0 to N identifiers to associate the event for a specific UE or flow. | [optional] 
**erab_info** | [**list[RabInfoErabInfo]**](RabInfoErabInfo.md) | Information on E-RAB as defined below. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

