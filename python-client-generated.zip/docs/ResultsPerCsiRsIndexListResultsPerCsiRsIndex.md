# ResultsPerCsiRsIndexListResultsPerCsiRsIndex

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**csi_rs_index** | **int** |  | [optional] 
**csi_rs_results** | [**MeasQuantityResultsNr**](MeasQuantityResultsNr.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

